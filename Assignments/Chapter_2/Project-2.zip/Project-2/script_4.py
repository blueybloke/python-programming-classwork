#Letter to Unicode
#Maxwell Phillips
#Date
#C Block Programming
#-------------------------------------------------------------------------------
#Algorithm:
#1)Greeting
#2)Input for letters and store as variables
#3)Print and format to Unicode
#-------------------------------------------------------------------------------
#Greeting
print("Hi, this is a lit program to change letterz to unicode.")
#Input
let_1 = str(input("Please input a lower case letter: "))
let_2 = str(input("Please input a upper case letter: "))
#Print & Format
print ("The first letter in unicode is: " + str(ord(let_1)))
print ("The second letter in unicode is: " +str(ord(let_2)))
